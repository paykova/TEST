package BookLibrary_24;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        Library library = new Library("SofiaUniversity");

        for (int i = 0; i < n; i++) {
            String[] arr = scan.nextLine().split(" ");

            String title = arr[0];
            String author = arr[1];
            String publisher = arr[2];
            String releaseDate = arr[3];
            String ISBN = arr[4];
            double price = Double.parseDouble(arr[5]);

            Book book = new Book(title, author, publisher, releaseDate, ISBN, price);
            library.getBooks().add(book);
        }

        Map<String, Double> authorSum = new LinkedHashMap<>();

        for (Book book : library.getBooks()) {
            if (authorSum.containsKey(book.getAuthor())) {
                double oldValue = authorSum.get(book.getAuthor());
                authorSum.put(book.getAuthor(), oldValue + book.getPrice());
            } else {
                authorSum.put(book.getAuthor(), book.getPrice());
            }
        }
        authorSum.entrySet()
                .stream()
                .sorted((a1,a2)->{
                    int compareResult=Double.compare(a2.getValue(),a1.getValue());

                    if (compareResult==0){
                        compareResult=a1.getKey().compareTo(a2.getKey());
                    }
                    return compareResult;
                })
                .forEach(a-> System.out.printf("%s -> %.2f%n",a.getKey(),a.getValue()));
    }
}
