package IntersectionOfCircles_22;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        Circle first = new Circle(
                new Point(scan.nextInt(),scan.nextInt()),
                scan.nextInt());

        Circle second = new Circle(
                new Point(scan.nextInt(),scan.nextInt()),
                scan.nextInt());

        if (intersect(first,second)){
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

    }

    public static boolean intersect(Circle first, Circle second) {
        double partX = Math.pow(first.getCenter().getX() - second.getCenter().getX(), 2);
        double partY = Math.pow(first.getCenter().getY() - second.getCenter().getY(), 2);

        double distance = Math.sqrt(partX + partY);

        return distance <= first.getRadius() + second.getRadius();
    }
}
