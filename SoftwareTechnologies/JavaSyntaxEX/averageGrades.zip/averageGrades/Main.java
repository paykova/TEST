package averageGrades;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Student> studentList = new ArrayList<>();

        int personsLength = Integer.parseInt(reader.readLine());

        for (int i = 0; i < personsLength; i++) {
            String[] input = reader.readLine().split(" ");
            String studentName = input[0];

            Student student = new Student(studentName);

            for (int j = 1; j < input.length; j++) {
                student.addGrade(Double.parseDouble(input[j]));
            }

            studentList.add(student);
        }

       studentList.stream()
               .filter(e -> e.averageGrade() >= 5.0)
               .sorted((e1,e2) -> {
                   int sort = e1.getName().compareTo(e2.getName());

                   if(sort == 0){
                        sort = Double.compare(e2.averageGrade(), e1.averageGrade());
                   }

                  return  sort;
               }).forEach(e -> {
           System.out.printf("%s -> %.2f\n", e.getName(), e.averageGrade());
       });
    }

}
