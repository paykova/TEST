package averageGrades;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student {

    private String name;
    private List<Double> grades;

     Student(String name) {
        this.setName(name);
        this.grades = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public List<Double> getGrades() {
        return Collections.unmodifiableList(this.grades);
    }

    void addGrade(Double grade){
        this.grades.add(grade);
    }

    Double averageGrade(){
        return this.grades.stream().mapToDouble(e -> e).average().getAsDouble();
    }

}
